# G8X.2024.T00.EG2
Guided Exercise 2
